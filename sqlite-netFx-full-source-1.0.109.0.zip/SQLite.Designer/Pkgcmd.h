#ifndef _PKGCMDS_
#define _PKGCMDS_

#define guidSharedBmps8                             {2b671d3d-ab51-434a-8d38-cbf1728530bb}
#define guidDavDataGrpId                            {732abe74-cd80-11d0-a2db-00aa00a3efff}
#define GUID_Mode_TableDesigner                     {4194fee5-6777-419f-a5fc-47a536df1bdb}

#define bmpid8LayoutDiagram                         0x0004
#define IDG_SCH_TOOLBAR_TABLEOPS                    0x1110
#define IDG_QRY_TOOLBAR_VIEWSHAPE                   0x1012

#endif
