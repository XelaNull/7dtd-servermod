/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("86636b58e29f85d17a2194bfacdb3b989a81b2bb")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2018-08-11 19:58:48 UTC")]
